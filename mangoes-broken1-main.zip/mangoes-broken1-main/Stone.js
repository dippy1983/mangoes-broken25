class Stone extends dgAlok{
constructor(x,y){
super(x,y,50,50)


}



}